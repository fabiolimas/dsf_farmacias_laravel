@extends('layouts.painel.app')
@section('title', 'Cadastrar novo exame')
@section('content')
    <div class="">
        <form action="{{ route('painel.admin.exames.store-2', $exame->id) }}" method="post" target="">
            @csrf
            <div class="row gy-4">


                <!--  exame -->
                <div class="col-12 col-lg-4 col-xl-4">
                    <div class="card ">
                        <div class="card-body p-3 p-lg-4">

                            <h1 class="fs-4 fw-600 mb-4 text-green-2 pt-2">Cadastrar novo exame</h1>



                            <!-- Nome do exame -->
                            <div class="mb-3 pb-2">
                                <label for="nome" class="form-label text-green fw-500 fs-18px">Nome do exame</label>
                                <input type="text"
                                    class="form-control form-control-custom fs-18px fw-500 @error('nome') is-invalid @enderror"
                                    name="nome" id="nome" value="{{ old('nome', $exame->nome) }}"
                                    placeholder="Ex: COVID-19" maxlength="255" required />
                                @error('nome')
                                    <div class="invalid-feedback fw-500">{{ $message }}</div>
                                @enderror
                            </div>
                            <!-- Laboratório -->
                            <div class="mb-3 pb-2">
                                <label for="laboratorio" class="form-label text-green fw-500 fs-18px">Laboratório</label>
                                <input type="text"
                                    class="form-control form-control-custom fs-18px fw-500 @error('laboratorio') is-invalid @enderror"
                                    name="laboratorio" id="laboratorio" maxlength="255"
                                    value="{{ old('laboratorio', $exame->laboratorio) }}" placeholder="Ex: Kovalent"
                                    required />
                                @error('laboratorio')
                                    <div class="invalid-feedback fw-500">{{ $message }}</div>
                                @enderror
                            </div>

                            <!-- Registro MS -->
                            <div class="mb-3 pb-2">
                                <label for="registro_ms" class="form-label text-green fw-500 fs-18px">
                                    Registro MS
                                </label>
                                <input type="text"
                                    class="form-control form-control-custom fs-18px fw-500 @error('registro_ms') is-invalid @enderror"
                                    name="registro_ms" id="registro_ms" maxlength="255"
                                    value="{{ old('registro_ms', $exame->registro_ms) }}" placeholder="00000" required />
                                @error('registro_ms')
                                    <div class="invalid-feedback fw-500">{{ $message }}</div>
                                @enderror
                            </div>

                            <div class="pt-3 mt-5">
                                <button type="submit" class="btn btn-primary w-100 py-2 fw-600">
                                    Cadastrar
                                </button>

                            </div>


                        </div>
                    </div>

                </div>

                <!-- perguntas -->
                <div class="col-12 col-lg-8 col-xl-8">
                    <div class="card ">
                        <div class="card-body p-3 p-lg-4">

                            <h1 class="fs-4 fw-600 mb-4 text-green-2 pt-2">Perguntas do exame</h1>

                            <!-- lista de parguntas -->
                            <div class="" id="lista-perguntas">
                                @foreach ([] as $key => $item)
                                @endforeach
                            </div>

                            <div class="mt-3 text-end">
                                <button type="button" class="btn btn-primary-light-3 px-4 fw-500" onclick="setPergunta()">
                                    <i class="" data-feather="plus-circle" width="20" height="20"></i>
                                    Adicionar mais
                                </button>
                            </div>

                        </div>
                    </div>

                </div>

            </div>
        </form>
    </div>


@endsection


@section('scripts')
    <script>
        /**
         * Adicionar opção para pergunta
         * @param {number} key - identificador principal da pergunta
         */
        function setOpcao(key) {
            let elOpcoes = document.querySelector(`#opcoes-resposta-${key}`)

            let newDiv = document.createElement('div')
            newDiv.className = `col-12 col-lg-6 item-opcoes-${key}`
            newDiv.innerHTML += `
                <div class="mb-3 pb-2 position-relative">
                    <label for="opcao2" class="form-label text-green fw-500 fs-18px">
                        Opção <span class="numero-opcao-${key}"></span>
                    </label>
                    <div class=" "
                        style="position: absolute; top: 42px; right: 13px; background: #E6F2F1">
                        <button type="button"
                            onclick="this.parentNode.parentNode.parentNode.remove(); setNumeroOpcao(${key})" title="Remover"
                            class="btn btn-none border-0 p-1 text-green fs-18px">
                            <i class="" data-feather="x"></i>
                        </button>
                    </div>
                    <div class=" "
                        style="position: absolute; top: 42px; right: 13px; background: #E6F2F1">
                        <button type="button"
                            class="btn btn-none border-0 p-1 text-green fs-18px"
                            onclick="this.parentNode.remove();setOpcao(${key})" title="Adicionar">
                            <i class="" data-feather="plus-circle"></i>
                        </button>
                    </div>

                    <input type="text"
                        class="form-control form-control-custom fs-18px fw-500"
                        name="perguntas[${key}][opcoes][]" id="opcao2"
                        placeholder="Resposta" value="" required />
                </div>
            `
            elOpcoes.appendChild(newDiv);
            setNumeroOpcao(key)

            /* activer feather icons */
            feather.replace();
        }

        /**
         * Organizar números de opções de perguntas
         * 
         * @param {number} key - identificador principal da pergunta
         */
        function setNumeroOpcao(key) {
            /* setar número opão em cada item */
            for (let i in document.querySelectorAll(`.numero-opcao-${key}`)) {
                document.querySelectorAll(`.numero-opcao-${key}`)[i].innerText = parseInt(i) + 1
            }
        }

        var contadorPerguntas = 0

        /*
         * Adicionar perguntas no html
         */
        function setPergunta() {

            contadorPerguntas += 1;

            let key = contadorPerguntas
            let divPerguntas = document.getElementById('lista-perguntas')

            console.log(key);

            let newDiv = document.createElement('div');

            newDiv.innerHTML = `
            <div class="border-green-light p-3 rounded-3 mb-4 pergunta-item" id="pergunta-item-${key}">
                <div class="row">
                    <!-- Pergunta -->
                    <div class="col-12 col-lg-6">
                        <div class="mb-3 pb-2">
                            <label for="pergunta"
                                class="form-label text-green fw-500 fs-18px">Pergunta</label>
                            <input type="text"
                                class="form-control form-control-custom fs-18px fw-500"
                                name="perguntas[${key}][pergunta]" id="pergunta"
                                placeholder="Forma de aplicação do exame?" required />
                        </div>
                    </div>

                    <div class="col-12 col-lg-6">
                        <!-- Tipo -->
                        <div class="mb-3 pb-2">
                            <label for="tipo"
                                class="form-label text-green fw-500 fs-18px opacity-0">Tipo</label>
                            <select class="form-select form-control-custom fw-500 fs-18px"
                                style="background-color: #CCEFEE"
                                name="perguntas[${key}][tipo]" id="tipo" required>
                                <option value="multipla-escolha">Múltipla escolha</option>
                                <option value="selecao">Seleção</option>
                                <option value="resposta-curta">Resposta curta</option>
                                <option value="paragrafo">Parágrafo</option>
                            </select>
                        </div>
                    </div>


                    <!-- Opções -->
                    <!-- op -->
                    <div class="col-12">
                        <div class="row flex-column" id="opcoes-resposta-${key}">

                            <!--  -->
                            <div class="col-12 col-lg-6 item-opcoes-${key}">
                                <div class="mb-3 pb-2 position-relative">
                                    <label for="opcao2"
                                        class="form-label text-green fw-500 fs-18px">
                                        Opção <span
                                            class="numero-opcao-${key}">${ key }</span>
                                    </label>
                                    <div class=" "
                                        style="position: absolute; top: 42px; right: 13px; background: #E6F2F1">
                                        <button type="button"
                                            onclick="this.parentNode.parentNode.remove(); setNumeroOpcao(${key})"
                                            class="btn btn-none border-0 p-1 text-green fs-18px">
                                            <i class="" data-feather="x"></i>
                                        </button>
                                    </div>
                                    <div class=" "
                                        style="position: absolute; top: 42px; right: 13px; background: #E6F2F1">
                                        <button type="button"
                                            class="btn btn-none border-0 p-1 text-green fs-18px"
                                            onclick="this.parentNode.remove();setOpcao(${key})">
                                            <i class="" data-feather="plus-circle"></i>
                                        </button>
                                    </div>

                                    <input type="text"
                                        class="form-control form-control-custom fs-18px fw-500"
                                        name="perguntas[${key}][opcoes][]"
                                        id="opcao2" placeholder="Nasal" value=""
                                        required />
                                </div>
                            </div>

                        </div>
                    </div>
                    <!-- op -->
                    <div class="col-12">
                        <div class="form-control form-control-custom d-flex align-items-center justify-content-end gap-3  border-end-0 border-start-0 border-bottom-0"
                            style="border-top-left-radius: 0;  border-top-right-radius: 0">

                            <button type="button" class="btn btn-none border-0 p-0 text-green-3"
                                title="Copiar pergunta" onclick="copiarPegunta(${key})">
                                <i class="" data-feather="copy"></i>
                            </button>
                            <button type="button" class="btn btn-none border-0 p-0 text-green-3"
                                data-bs-toggle="tooltip" data-bs-placement="top" title="Remover" onclick="this.parentNode.parentNode.parentNode.parentNode.parentNode.remove()">
                                <i class="" data-feather="trash"></i>
                            </button>


                            <div class=""
                                style="height: 20px; border-left: 1px solid #B2D2D2">

                            </div>
                            <div class="fw-500 d-flex gap-1 align-items-center">

                                <label class="form-check-label"
                                    for="flexSwitchCheckDefault">Obrigatória</label>

                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox"
                                        name="perguntas[${key}][obrigatorio]"
                                        role="switch" id="flexSwitchCheckDefault">
                                </div>


                            </div>
                        </div>
                    </div>


                </div>
            </div>
            `

            divPerguntas.appendChild(newDiv);

            /* activer feather icons */
            feather.replace();
        }
        setPergunta()

        /**
         * Copiar pergunta
         * @param {number} key - identificador principal da pergunta
         */
        function copiarPegunta(key) {
            // let htmlOriginal= document.getElementById(`pergunta-item-${key}`).innerHTML

            // let divPerguntas = document.getElementById('lista-perguntas')

            // let newDiv = document.createElement('div');

            // newDiv.innerHTML=htmlOriginal

            // divPerguntas.appendChild(newDiv);

            // let newDiv = document.createElement('div');

        }
    </script>
@endsection
